# Requirement
Please make sure you have .NET Core 3.1 Desktop Runtime (v3.1.21) - Windows x86 installed on your PC
Frija executable requires x86 version of the runtime even on x64 platform so make sure you have the right version installed

## Runtime download link
https://dotnet.microsoft.com/download/dotnet/thank-you/runtime-desktop-3.1.21-windows-x86-installer